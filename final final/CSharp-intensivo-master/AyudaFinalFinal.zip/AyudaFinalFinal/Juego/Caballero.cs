﻿using System;
namespace Juego
{
    public class Caballero: Guerrero
    {
        public Caballero(): base(100, 2, 3)
        {
        }

        protected override void Atacar(Guerrero b)
        {
            // Hacer
        }

        protected override void Defender()
        {
            // Hacer
        }

        protected override void CastearHechizo(Guerrero b)
        {
            // Hacer
        }
    }
}
